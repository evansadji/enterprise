# -*- coding: utf-8 -*-
# Copyright 2015 LasLabs Inc.
# License GPL-3.0 or later (http://www.gnu.org/licenses/gpl.html).

from . import medical_insurance_company
from . import medical_insurance_template
from . import medical_insurance_plan
from . import medical_patient
from . import product_product
from . import res_partner
